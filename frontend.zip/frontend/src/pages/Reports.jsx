import React from 'react'

const Reports = () => {
  return (
    <div>
      report 
    </div>
  )
}

export default Reports
