import React from 'react'

const PendingNotes = () => {
    return (
        <div>
            pending notes
        </div>
    )
}

export default PendingNotes
