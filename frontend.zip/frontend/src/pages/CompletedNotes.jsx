import React from 'react'

const CompletedNotes = () => {
  return (
    <div>
      completed
    </div>
  )
}

export default CompletedNotes