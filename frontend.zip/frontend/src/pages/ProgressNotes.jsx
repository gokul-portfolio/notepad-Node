import React from 'react'

const ProgressNotes = () => {
    return (
        <div>
            progress
        </div>
    )
}

export default ProgressNotes
