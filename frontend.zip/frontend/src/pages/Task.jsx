import React from 'react'

const Task = () => {
  return (
    <div>Task</div>
  )
}

export default Task